package rough;

import com.crm.qa.util.TestUtil;

public class TestGetDataMethod {

	public static void main(String[] args) {
		TestUtil.getTestData("Contacts");
	}
}
